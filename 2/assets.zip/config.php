<?php
$host = 'localhost';
$username = 'vixc4934_pulsa';
$password = 'pulsa123';
$name = 'vixc4934_pulsa';
	$con = mysqli_connect($host,$username,$password,$name);
?>